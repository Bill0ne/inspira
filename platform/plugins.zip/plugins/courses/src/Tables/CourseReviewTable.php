<?php

namespace Botble\Courses\Tables;

use Botble\Base\Facades\BaseHelper;
use Botble\Base\Facades\Html;
use Botble\Hotel\Enums\ReviewStatusEnum;
use Botble\Courses\Models\CourseReview;
use Botble\Table\Abstracts\TableAbstract;
use Botble\Table\Actions\DeleteAction;
use Botble\Table\BulkActions\DeleteBulkAction;
use Botble\Table\Columns\Column;
use Botble\Table\Columns\CreatedAtColumn;
use Botble\Table\Columns\IdColumn;
use Botble\Table\Columns\StatusColumn;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Database\Query\Builder as QueryBuilder;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class CourseReviewTable extends TableAbstract
{
    public function setup(): void
    {
        $this
            ->model(CourseReview::class)
            ->addActions([
                DeleteAction::make()->route('course-review.destroy'),
            ]);
    }

    public function ajax(): JsonResponse
    {
        $data = $this->table
            ->eloquent($this->query())
            ->editColumn('customer_id', function (CourseReview $item) {
                if (! $item->customer_id || ! $item->author?->id) {
                    return '&mdash;';
                }

                return Html::link(route('customer.edit', $item->author->id), BaseHelper::clean($item->author->name))->toHtml();
            })
            ->editColumn('course_id', function (CourseReview $item) {
                if (! $item->course_id) {
                    return '&mdash;';
                }

                return Html::link(route('course.edit', $item->course_id), BaseHelper::clean($item->course->name))->toHtml();
            })
            ->editColumn('star', function (CourseReview $item) {
                return view('plugins/hotel::partials.review-star', ['star' => $item->star])->render();
            })
            ->editColumn('content', function (CourseReview $item) {
                return BaseHelper::clean($item->content);
            })
            ->filter(function ($query) {
                $keyword = $this->request->input('search.value');

                if ($keyword) {
                    $keywordLike = '%' . $keyword . '%';

                    return $query
                        ->where(function ($sub) use ($keywordLike) {
                            // ✅ Search by author name
                            $sub->whereHas('author', function ($subQuery) use ($keywordLike) {
                                $subQuery
                                    ->where('first_name', 'LIKE', $keywordLike)
                                    ->orWhere('last_name', 'LIKE', $keywordLike)
                                    ->orWhere(DB::raw("CONCAT(first_name, ' ', last_name)"), 'LIKE', $keywordLike);
                            })
                                // ✅ Search by course name
                                ->orWhereHas('course', function ($subQuery) use ($keywordLike) {
                                    $subQuery->where('name', 'LIKE', $keywordLike);
                                })
                                // ✅ Search by review content
                                ->orWhere('content', 'LIKE', $keywordLike);
                        });
                }

                return $query;
            });

        return $this->toJson($data);
    }

    public function query(): Relation|Builder|QueryBuilder
    {
        $query = $this
            ->getModel()
            ->query()
            ->select([
                'id',
                'course_id',
                'star',
                'content',
                'customer_id',
                'status',
                'created_at',
            ])
            ->with(['author']);

        return $this->applyScopes($query);
    }

    public function columns(): array
    {
        return [
            IdColumn::make(),
            Column::make('customer_id')
                ->title(trans('plugins/hotel::review.author'))
                ->alignLeft(),
            Column::make('course_id')
                ->title(trans('plugins/courses::courses.course.name'))
                ->alignLeft()
                ->orderable(false)
                ->searchable(false),
            Column::make('star')
                ->title(trans('plugins/hotel::review.star')),
            Column::make('content')
                ->title(trans('plugins/hotel::review.content')),
            CreatedAtColumn::make(),
            StatusColumn::make(),
        ];
    }

    public function bulkActions(): array
    {
        return [
            DeleteBulkAction::make()->permission('course-review.destroy'),
        ];
    }

    public function getBulkChanges(): array
    {
        return [
            'status' => [
                'title' => trans('core/base::tables.status'),
                'type' => 'select',
                'choices' => ReviewStatusEnum::labels(),
                'validate' => 'required|in:' . implode(',', ReviewStatusEnum::values()),
            ],
            'created_at' => [
                'title' => trans('core/base::tables.created_at'),
                'type' => 'datePicker',
            ],
        ];
    }
}
