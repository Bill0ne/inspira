<table class="table table-bordered">
    <thead>
    <tr>
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Seats</th>
        <th>Payment Status</th>
    </tr>
    </thead>
    <tbody>
    @forelse ($bookings as $index => $booking)
        <tr>
            <td>{{ $index + 1 }}</td>
            <td>{{ $booking->customer->name ?? 'N/A' }}</td>
            <td>{{ $booking->customer->email ?? 'N/A' }}</td>
            <td>{{ $booking->customer->phone ?? 'N/A' }}</td>
            <td>{{ $booking->seats ?? 1 }}</td>
            <td>{!!$booking->payment?->status->toHtml() !!}</td>
        </tr>
    @empty
        <tr>
            <td colspan="6" class="text-center">No participants found.</td>
        </tr>
    @endforelse
    </tbody>
</table>
